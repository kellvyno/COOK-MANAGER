import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl = "https://jsonplaceholder.typicode.com";

  // Busca todas as informações (usado pelo colaborador)
  Future<List<dynamic>> fetchInformacoes() async {
    final response = await http.get(Uri.parse('$baseUrl/posts'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception("Erro ao buscar informações da API");
    }
  }

  // Envia novas informações (usado pelo administrador)
  Future<void> enviarDados(Map<String, dynamic> dados) async {
    final response = await http.post(
      Uri.parse('$baseUrl/posts'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(dados),
    );

    if (response.statusCode != 201) {
      throw Exception("Erro ao enviar dados: ${response.body}");
    }
  }
}
