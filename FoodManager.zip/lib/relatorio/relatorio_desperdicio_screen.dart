import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class RelatoriosScreen extends StatelessWidget {
  const RelatoriosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length:
          2, // Certifique-se de que este valor seja igual ao número de abas e de children
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Relatórios'),
          backgroundColor: Colors.red,
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.calendar_today), text: 'Relatório Diário'),
              Tab(icon: Icon(Icons.bar_chart), text: 'Gráfico Mensal'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            RelatorioDiario(), // Primeira aba: Relatório Diário
            GraficoMensal(), // Segunda aba: Gráfico Mensal
          ],
        ),
      ),
    );
  }
}

class GraficoMensal extends StatelessWidget {
  const GraficoMensal({super.key});

  @override
  Widget build(BuildContext context) {
    final List<BarChartGroupData> data = [
      BarChartGroupData(
        x: 1,
        barRods: [
          BarChartRodData(toY: 5, color: Colors.orange),
        ],
      ),
      BarChartGroupData(
        x: 2,
        barRods: [
          BarChartRodData(toY: 3, color: Colors.blue),
        ],
      ),
      BarChartGroupData(
        x: 3,
        barRods: [
          BarChartRodData(toY: 7, color: Colors.green),
        ],
      ),
      BarChartGroupData(
        x: 4,
        barRods: [
          BarChartRodData(toY: 2, color: Colors.purple),
        ],
      ),
      BarChartGroupData(
        x: 5,
        barRods: [
          BarChartRodData(toY: 6, color: Colors.red),
        ],
      ),
    ];

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Desperdício do Mês',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: BarChart(
              BarChartData(
                borderData: FlBorderData(
                    show: true,
                    border: Border.all(color: Colors.grey, width: 1)),
                gridData: FlGridData(
                    show: true,
                    horizontalInterval: 1,
                    verticalInterval: 1,
                    drawHorizontalLine: true), // Definido uma vez
                barGroups: data,
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    axisNameWidget: const Text(
                      'Quantidade',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.black),
                    ),
                    sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          return Text('${value.toInt()}g',
                              style: TextStyle(fontSize: 12));
                        }),
                  ),
                  bottomTitles: AxisTitles(
                    axisNameWidget: const Text(
                      'Categorias',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.black),
                    ),
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        switch (value.toInt()) {
                          case 1:
                            return const Text('Frutas',
                                style: TextStyle(color: Colors.orange));
                          case 2:
                            return const Text('Carnes',
                                style: TextStyle(color: Colors.blue));
                          case 3:
                            return const Text('Verduras',
                                style: TextStyle(color: Colors.green));
                          case 4:
                            return const Text('Legumes',
                                style: TextStyle(color: Colors.purple));
                          case 5:
                            return const Text('Cereais',
                                style: TextStyle(color: Colors.red));
                          default:
                            return const Text('');
                        }
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RelatorioDiario extends StatelessWidget {
  const RelatorioDiario({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Desperdicio> desperdiciosDiarios = [
      Desperdicio(data: '25/11/2024', alimento: 'Morango', quantidade: 500),
      Desperdicio(data: '30/11/2024', alimento: 'Frango', quantidade: 1000),
      Desperdicio(data: '30/11/2024', alimento: 'Arroz', quantidade: 200),
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(8.0),
      itemCount: desperdiciosDiarios.length,
      itemBuilder: (context, index) {
        final desperdicio = desperdiciosDiarios[index];
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: ListTile(
            title: Text('${desperdicio.alimento} - ${desperdicio.quantidade}g'),
            subtitle: Text('Data: ${desperdicio.data}'),
          ),
        );
      },
    );
  }
}

class Desperdicio {
  final String data;
  final String alimento;
  final int quantidade;

  Desperdicio({
    required this.data,
    required this.alimento,
    required this.quantidade,
  });
}
