import 'package:flutter/material.dart';
import 'screen/login_screen.dart';

void main() {
  runApp(const GestorDesperdicioApp());
}

class GestorDesperdicioApp extends StatelessWidget {
  const GestorDesperdicioApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gestor de Desperdício',
      theme: ThemeData.dark(),
      home: const LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
