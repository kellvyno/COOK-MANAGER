import 'package:flutter/material.dart';

class GaleriaScreen extends StatelessWidget {
  const GaleriaScreen({Key? key}) : super(key: key);

  final List<Map<String, dynamic>> registros = const [
    {
      'imagem': 'assets/sample1.png',
      'nome': 'Registro 1',
      'detalhes': 'Detalhes do registro 1'
    },
    {
      'imagem': 'assets/sample2.png',
      'nome': 'Registro 2',
      'detalhes': 'Detalhes do registro 2'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Galeria'),
        backgroundColor: Colors.red,
      ),
      body: ListView.builder(
        itemCount: registros.length,
        itemBuilder: (context, index) {
          final registro = registros[index];
          return Card(
            margin: const EdgeInsets.all(8.0),
            child: ListTile(
              leading: Image.asset(
                registro['imagem'],
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(registro['nome']),
              subtitle: Text(registro['detalhes']),
            ),
          );
        },
      ),
    );
  }
}
