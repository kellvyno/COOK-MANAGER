// lib/services/sistema_relatorios.dart

// ignore_for_file: unused_import

import 'dart:convert';
import 'dart:io';
import 'package:foodmanager/screen/relatorio.dart';

class SistemaRelatorios {
  final String caminhoArquivo =
      'relatorios.json'; // Caminho do arquivo de relatórios

  // Carregar os relatórios do arquivo
  Future<List<Map<String, dynamic>>> carregarRelatorios() async {
    try {
      final file = File(caminhoArquivo);
      if (await file.exists()) {
        final String conteudo = await file.readAsString();
        return List<Map<String, dynamic>>.from(json.decode(conteudo));
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }

  // Salvar relatório no arquivo JSON
  Future<void> salvarRelatorio(int adminId, Relatorio relatorio) async {
    final relatorios = await carregarRelatorios();

    // Adiciona o novo relatório
    relatorios.add({
      'adminId': adminId,
      'relatorio': relatorio.toJson(),
    });

    // Salvar novamente o arquivo com os dados atualizados
    final file = File(caminhoArquivo);
    await file.writeAsString(json.encode(relatorios));

    // Propagar o relatório para os colaboradores (simulado)
    propagarRelatorioParaColaboradores(adminId, relatorio);
  }

  // Simula a propagação de um relatório para os colaboradores
  void propagarRelatorioParaColaboradores(int adminId, Relatorio relatorio) {
    print(
        'Relatório "${relatorio.titulo}" propagado para os colaboradores do Admin $adminId');
  }
}
