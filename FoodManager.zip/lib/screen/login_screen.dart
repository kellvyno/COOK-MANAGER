import 'package:flutter/material.dart';
import 'registro_screen.dart'; // Certifique-se de que o arquivo está importado
import 'user_type_screen.dart'; // Certifique-se de que o arquivo está importado

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Parte cinza superior com borda arredondada
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200, // Altura da parte cinza
            child: ClipRRect(
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(00),
              ),
              child: Container(
                color: const Color(0xffe0e0e0), // Cor cinza
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      'foodmanage.png', // Logo original
                      width: 100, // Ajuste o tamanho se necessário
                      height: 100,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'CookManager',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Pacifico', // Fonte personalizada
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Conteúdo principal
          Positioned.fill(
            top: 200, // Ajuste para alinhar ao novo tamanho da parte cinza
            child: Column(
              children: [
                const Spacer(), // Empurra os botões para a parte inferior
                // Botão de Login
                SizedBox(
                  width: 250, // Define a largura fixa
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const UserTypeScreen(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      'Login',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                // Botão de Cadastro
                SizedBox(
                  width: 250, // Define a mesma largura fixa
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const RegistroScreen(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      'Cadastro',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                ),
                const Spacer(flex: 2), // Espaço maior antes do botão "Sair"
                // Container vermelho com bordas superiores arredondadas para o botão "Sair"
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(00),
                    topRight: Radius.circular(30),
                  ),
                  child: Container(
                    color: Colors.red,
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Center(
                      child: ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xffe0e0e0),
                          foregroundColor: const Color(0xff070707),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 32, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          elevation: 0,
                        ),
                        child: const Text(
                          'Sair',
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
