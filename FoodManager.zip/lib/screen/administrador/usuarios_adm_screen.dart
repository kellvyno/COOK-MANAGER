import 'package:flutter/material.dart';

class UsuariosAdmScreen extends StatefulWidget {
  const UsuariosAdmScreen({super.key});

  @override
  State<UsuariosAdmScreen> createState() => _UsuariosAdmScreenState();
}

class _UsuariosAdmScreenState extends State<UsuariosAdmScreen> {
  List<Map<String, String>> usuarios = [
    {'nome': 'Usuário 1', 'status': 'Conectado'},
    {'nome': 'Usuário 2', 'status': 'Desconectado'},
    {'nome': 'Usuário 3', 'status': 'Conectado'},
    {'nome': 'Usuário 4', 'status': 'Desconectado'},
  ];

  List<Map<String, String>> usuariosFiltrados = [];

  @override
  void initState() {
    super.initState();
    usuariosFiltrados = List.from(usuarios);
  }

  void _filtrarUsuarios(String query) {
    setState(() {
      usuariosFiltrados = usuarios
          .where((usuario) =>
              usuario['nome']!.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  void _removerUsuario(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Confirmar exclusão'),
          content: Text(
              'Tem certeza que deseja remover ${usuariosFiltrados[index]['nome']}?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context), // Cancelar
              child: const Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  usuarios.remove(usuariosFiltrados[index]);
                  usuariosFiltrados.removeAt(index);
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Usuário removido com sucesso')),
                );
              },
              child: const Text('Remover'),
            ),
          ],
        );
      },
    );
  }

  void _adicionarUsuario() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Adicionar Novo Usuário')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading:
            true, // Garante que apenas a seta padrão seja usada
        title: const Text('Usuários'),
        backgroundColor: Colors.red,
      ),
      body: Column(
        children: [
          // Cabeçalho com barra de busca
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: Color(0xFFBFBFBF), // Fundo cinza claro
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              children: [
                const Text(
                  'Usuários Conectados',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  decoration: const InputDecoration(
                    hintText: 'Buscar usuário',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: _filtrarUsuarios,
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // Lista de usuários
          Expanded(
            child: usuariosFiltrados.isEmpty
                ? const Center(
                    child: Text(
                      'Nenhum usuário encontrado.',
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    itemCount: usuariosFiltrados.length,
                    itemBuilder: (context, index) {
                      final usuario = usuariosFiltrados[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 3,
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.red,
                            child: Text(
                              usuario['nome']![0],
                              style: const TextStyle(color: Colors.white),
                            ),
                          ),
                          title: Text(usuario['nome']!),
                          subtitle: Text('Status: ${usuario['status']}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon:
                                    const Icon(Icons.edit, color: Colors.blue),
                                onPressed: () {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content:
                                          Text('Editar ${usuario['nome']}'),
                                    ),
                                  );
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.remove_circle,
                                    color: Colors.red),
                                onPressed: () => _removerUsuario(index),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      // Barra inferior para adicionar usuários
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(10),
        color: Colors.black,
        child: ElevatedButton.icon(
          onPressed: _adicionarUsuario,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            padding: const EdgeInsets.symmetric(vertical: 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
          ),
          icon: const Icon(Icons.add, color: Colors.white),
          label: const Text(
            'Adicionar Usuário',
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
    );
  }
}
