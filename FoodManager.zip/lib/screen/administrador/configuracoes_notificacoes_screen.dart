import 'package:flutter/material.dart';

class ConfiguracoesNotificacoesScreen extends StatelessWidget {
  const ConfiguracoesNotificacoesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Configurações de Notificações'),
        backgroundColor: Colors.red,
      ),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('Notificações por E-mail'),
            value: true, // Simulação de estado (mude conforme necessário)
            onChanged: (value) {
              // Atualizar estado das notificações por e-mail
            },
          ),
          SwitchListTile(
            title: const Text('Notificações Push'),
            value: false, // Simulação de estado (mude conforme necessário)
            onChanged: (value) {
              // Atualizar estado das notificações push
            },
          ),
        ],
      ),
    );
  }
}
