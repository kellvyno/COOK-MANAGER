import 'package:flutter/material.dart';

class AlterarEmailScreen extends StatelessWidget {
  const AlterarEmailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alterar E-mail'),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const TextField(
              decoration: InputDecoration(
                labelText: 'Novo E-mail',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                // Atualizar e-mail
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text('E-mail atualizado com sucesso!')),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Atualizar E-mail'),
            ),
          ],
        ),
      ),
    );
  }
}
