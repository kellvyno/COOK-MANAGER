import 'package:flutter/material.dart';
import 'historico_adm_screen.dart';
import 'configuracoes_adm_screen.dart';
import 'package:foodmanager/services/api_service.dart';
import 'package:foodmanager/relatorio/relatorio_desperdicio_screen.dart';
import 'dashboard_screen.dart';

class AdministradorScreen extends StatefulWidget {
  const AdministradorScreen({Key? key}) : super(key: key);

  @override
  State<AdministradorScreen> createState() => _AdministradorScreenState();
}

class _AdministradorScreenState extends State<AdministradorScreen> {
  int _currentIndex = 0;

  // Lista de telas para navegação
  final List<Widget> _screens = [
    const DashboardScreen(),
    const HistoricoAdmScreen(userId: 'Todos'),
    const ConfiguracoesAdmScreen(),
    const FormularioAdmScreen(),
    const RelatoriosScreen(), // Substituído o antigo GraficosScreen
  ];

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Administrador'),
        backgroundColor: Colors.red,
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Início',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Histórico',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Configurações',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.edit),
            label: 'Formulário',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Relatórios',
          ),
        ],
        selectedItemColor: Colors.red,
        unselectedItemColor: Colors.grey,
        backgroundColor: Colors.black,
      ),
    );
  }
}

class FormularioAdmScreen extends StatefulWidget {
  const FormularioAdmScreen({Key? key}) : super(key: key);

  @override
  State<FormularioAdmScreen> createState() => _FormularioAdmScreenState();
}

class _FormularioAdmScreenState extends State<FormularioAdmScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _tituloController = TextEditingController();
  final TextEditingController _descricaoController = TextEditingController();

  Future<void> _enviarDados() async {
    if (_formKey.currentState!.validate()) {
      try {
        final apiService = ApiService();
        await apiService.enviarDados({
          'title': _tituloController.text,
          'body': _descricaoController.text,
          'userId': 1,
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Dados enviados com sucesso!')),
        );
        _tituloController.clear();
        _descricaoController.clear();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao enviar dados: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Formulário Administrador'),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _tituloController,
                decoration: const InputDecoration(labelText: 'Título'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira um título.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descricaoController,
                decoration: const InputDecoration(labelText: 'Descrição'),
                maxLines: 5,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira uma descrição.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _enviarDados,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: const Text('Enviar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
