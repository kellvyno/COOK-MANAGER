import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Logo
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 5),
              child: Image.asset(
                'foodmanage.png', // Logo do aplicativo
                width: 120,
                height: 120,
              ),
            ),
          ),
          // Título
          Container(
            padding: const EdgeInsets.all(2),
            child: const Center(
              child: Text(
                'CookManager',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          // Indicadores do painel
          Expanded(
            child: GridView.count(
              crossAxisCount: 2,
              padding: const EdgeInsets.all(16),
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              children: [
                _buildDashboardCard('Desperdício', '15%', Icons.bar_chart),
                _buildDashboardCard('Usuários Ativos', '8', Icons.people),
                _buildDashboardCard('Registros hoje', '12', Icons.list_alt),
                _buildDashboardCard('Atualizações', '3', Icons.feedback),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Método para criar os cards do dashboard
  Widget _buildDashboardCard(String title, String value, IconData icon) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.red),
            const SizedBox(height: 10),
            Text(
              value,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            Text(title, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
