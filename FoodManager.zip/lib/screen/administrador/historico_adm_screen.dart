import 'package:flutter/material.dart';

class HistoricoAdmScreen extends StatelessWidget {
  final String userId; // ID do usuário para exibir o histórico específico

  const HistoricoAdmScreen({super.key, required this.userId});

  @override
  Widget build(BuildContext context) {
    // Exemplo de dados de histórico fictícios
    final List<Map<String, String>> historico = [
      {"data": "18/11/2024", "evento": "Usuário 234 adicionou um registro"},
      {"data": "17/11/2024", "evento": "Usuário 123 adicionou um registro"},
      {"data": "16/11/2024", "evento": "Usuário 456 adicionou um registro"},
      {"data": "15/11/2024", "evento": "Usuário 789 adicionou um registro"},
    ];

    String _selectedUser = 'Todos'; // Valor inicial do Dropdown

    return Scaffold(
      body: Column(
        children: [
          // Container substituindo o AppBar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: Color(0xffd0cbca),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: DropdownButton<String>(
                    value: _selectedUser,
                    icon: const Icon(Icons.arrow_downward,
                        color: Color(0xff080808)),
                    dropdownColor: Colors.red,
                    underline: Container(), // Remove a linha inferior
                    style: const TextStyle(color: Color(0xff0a0a0a)),
                    items: <String>[
                      'Todos',
                      'Usuário 1',
                      'Usuário 2',
                      'Usuário 3'
                    ].map((String user) {
                      return DropdownMenuItem<String>(
                        value: user,
                        child: Text(user),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      if (newValue != null) {
                        _selectedUser = newValue;
                        // Atualize aqui a lógica para buscar o histórico do usuário selecionado
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // Lista do histórico
          Expanded(
            child: ListView.builder(
              itemCount: historico.length,
              itemBuilder: (context, index) {
                final item = historico[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 3,
                  child: ListTile(
                    leading: const Icon(Icons.event, color: Colors.red),
                    title: Text(item["evento"] ?? ""),
                    subtitle: Text(item["data"] ?? ""),
                    trailing: IconButton(
                      icon:
                          const Icon(Icons.remove_red_eye, color: Colors.blue),
                      onPressed: () {
                        // Ação para exibir detalhes do registro
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                              content:
                                  Text('Exibindo registro: ${item["evento"]}')),
                        );
                      },
                    ),
                  ),
                );
              },
            ),
          ),

          // Rodapé com informação adicional
          Container(
            padding: const EdgeInsets.all(10),
            child: Text(
              "Total de eventos: ${historico.length}",
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
