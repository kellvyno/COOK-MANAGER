import 'package:flutter/material.dart';
import 'editar_perfil_screen.dart';
import 'alterar_senha_screen.dart';
import 'alterar_email_screen.dart';
import 'configuracoes_notificacoes_screen.dart';
import 'usuarios_adm_screen.dart';

class ConfiguracoesAdmScreen extends StatelessWidget {
  const ConfiguracoesAdmScreen({super.key});

  // Método para navegar entre as telas
  void _navegarParaTela(BuildContext context, Widget tela) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => tela),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar removido conforme solicitado
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Seção de Perfil
          _buildListTile(
            context,
            Icons.person,
            'Perfil',
            'Editar nome, foto e outras informações pessoais',
            const EditarPerfilScreen(),
          ),
          const Divider(),

          // Seção de Senha
          _buildListTile(
            context,
            Icons.lock,
            'Alterar Senha',
            '',
            const AlterarSenhaScreen(),
          ),
          const Divider(),

          // Seção de E-mail
          _buildListTile(
            context,
            Icons.email,
            'Alterar E-mail',
            '',
            const AlterarEmailScreen(),
          ),
          const Divider(),

          // Opção de Notificações
          _buildListTile(
            context,
            Icons.notifications,
            'Notificações',
            'Gerenciar preferências de notificações',
            const ConfiguracoesNotificacoesScreen(),
          ),
          const Divider(),

          // Opção de Usuários
          _buildListTile(
            context,
            Icons.people,
            'Gerenciar Usuários',
            'Visualizar e gerenciar os usuários conectados',
            const UsuariosAdmScreen(),
          ),
          const Divider(),

          // Opção de Tema
          ListTile(
            leading: const Icon(Icons.palette, color: Colors.red),
            title: const Text(
              'Tema do Aplicativo',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: const Text('Alterar entre modo claro e escuro'),
            onTap: () {
              // Alternar entre modo claro e escuro
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Alterar Tema'),
                  content: const Text('Escolha entre modo claro e escuro.'),
                  actions: [
                    TextButton(
                      onPressed: () {
                        // Implementar lógica para modo claro
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Tema claro ativado!')),
                        );
                      },
                      child: const Text('Claro'),
                    ),
                    TextButton(
                      onPressed: () {
                        // Implementar lógica para modo escuro
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Tema escuro ativado!')),
                        );
                      },
                      child: const Text('Escuro'),
                    ),
                  ],
                ),
              );
            },
          ),
          const Divider(),

          // Opção de Suporte
          ListTile(
            leading: const Icon(Icons.support, color: Colors.red),
            title: const Text(
              'Suporte',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: const Text('Entrar em contato com o suporte técnico'),
            onTap: () {
              // Abrir caixa de diálogo com informações de contato
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Suporte Técnico'),
                  content: const Text(
                      'Para assistência, entre em contato pelo e-mail suporte@foodmanager.com.'),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text('OK'),
                    ),
                  ],
                ),
              );
            },
          ),
          const Divider(),
        ],
      ),
    );
  }

  // Método para gerar ListTile reutilizável
  Widget _buildListTile(BuildContext context, IconData icon, String title,
      String subtitle, Widget nextScreen) {
    return ListTile(
      leading: Icon(icon, color: Colors.red),
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: Text(subtitle),
      onTap: () => _navegarParaTela(context, nextScreen),
    );
  }
}
