class Relatorio {
  final String titulo;
  final String descricao;
  final DateTime data;

  Relatorio({
    required this.titulo,
    required this.descricao,
    required this.data,
  });

  // Método para converter o objeto em um Map (que pode ser convertido em JSON)
  Map<String, dynamic> toJson() {
    return {
      'titulo': titulo,
      'descricao': descricao,
      'data': data
          .toIso8601String(), // Usamos toIso8601String() para formatar a data como string
    };
  }

  // Método para criar o objeto a partir de um Map (usado ao deserializar JSON)
  factory Relatorio.fromJson(Map<String, dynamic> json) {
    return Relatorio(
      titulo: json['titulo'],
      descricao: json['descricao'],
      data: DateTime.parse(
          json['data']), // Converte a data de volta para DateTime
    );
  }
}
